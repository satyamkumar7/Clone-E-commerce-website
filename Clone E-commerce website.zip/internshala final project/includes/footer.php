<footer>
   <div class="container">
<div class="col-md-3 col-sm-6 home-feature">
                        <div class="caption">
                            <h3>Information </h3>
                            <a href="about us.php"> <p>About Us</p> </a>
                            <a href="contact us.php"> <p>Contact Us</p> </a>
                        </div>
</div>
<div class="col-md-3 col-sm-6 home-feature">
                        <div class="caption">
                            <h3>Account </h3>
                            <a href="login.php"> <p>Login</p> </a>
                            <a href="signup.php"> <p>Sign Up</p> </a>
                        </div>
</div>
<div class="col-md-3 col-sm-6 home-feature">
                        <div class="caption">
                            <h3>Contact Us </h3>
                            <p> Contact: +91-123-000000</p>
                        </div>
</div>
<div class="col-md-3 col-sm-6 home-feature">
                        <div class="caption">
                            <h3>Download App </h3>
                            <a href="https://play.google.com/store?utm_source=apac_med&utm_medium=hasem&utm_content=Jul0121&utm_campaign=Evergreen&pcampaignid=MKT-EDR-apac-in-1003227-med-hasem-py-Evergreen-Jul0121-Text_Search_BKWS-BKWS%7cONSEM_kwid_43700065205026412_creativeid_535350509915_device_c&gclid=CjwKCAjw9aiIBhA1EiwAJ_GTSl_K1r07R50xRx_EXVHtWUkzdtVVBbnRwJkEE84N563PaY_7gyvMXhoCn8UQAvD_BwE&gclsrc=aw.ds" class="glyphicon glyphicon-download-alt fab fa-google-play">  Google Play</a>
                        </div>
</div>
</div><br>
    <div class="container">
        <center>
            <p>Copyright &copy; Lifestyle Store. All Rights Reserved  |  Contact Us: +91 90000 00000</p>	
        </center>
    </div>
</footer>