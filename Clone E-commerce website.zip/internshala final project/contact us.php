<?php
require("includes/common.php");
// Redirects the user to products page if logged in.
if (isset($_SESSION['email'])) {
    header('location: products.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
</head>
<body>
<?php include 'includes/header.php'; ?>

<div class="container">
<div class="col-md-10 sm-10">
    <h2>LIVE SUPPORT</h2>
    <h5>24 hours | 7 days a week | 365 days a year live technical support</h5>
    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using  lorem  lpsum is that it has a more-or-less normal distribution of letters. There are many variations of passages of Lorem lpsum available  , but majority  have suffered alteration in some form , by injected humour , or randomised words which don't look even slightly believable .  If you are going to use a  passage of Lorem lpsum , you need to be sure that isn't anything embarrasing hidden in the middle of text <br></p>
</div>
<div class="container">
<div class="col-md-2 sm-2">
   <img src="img/contact.png" alt="">
</div>
</div>
<div class="container">
<div class="col-md-8 sm-8">
    <h1>CONTACT US</h1><br>
    <form action="">
        Name <br> <input type="text" name="name" id="name"><br><br>
        E-mail <br><input type="email" name="email" id="email"><br><br>
        Message <br><textarea name="myText" cols="80" rows="10"></textarea><br>
        <button>submit</button><br><br><br><br><br>
    </form>
</div>
<div class="container">
    <div class="col-md-4 sm-4">
        <h2>Company Information</h2><br>
        <p>500 Chicago ,New York</p><br>
        <p>22-56-2-9  Manchestar,<br>USA</p><br>
        <p>Phone: (00) 222 666 444</p><br>
        <p>Fax: (00) 000 000 00</p><br>
        <p>Email: info@lifestylestore.com</p><br>
        <p>Follow on: Faceook,Twitter</p>
    </div>
</div>

</div>
</div>

<?php include("includes/footer.php"); ?>

</body>
</html>