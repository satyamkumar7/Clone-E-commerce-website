<?php
require("includes/common.php");
// Redirects the user to products page if logged in.
if (isset($_SESSION['email'])) {
    header('location: products.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
</head>
<body>
<?php include 'includes/header.php'; ?>
    <div class="container">
        <div class="col-md-4 sm-6">
            <h2>WHO WE ARE</h2>
            <img src="img/about-img.jpg" alt=""><br><br>
            
            <p>E-commerce is an electronic commerce company <br> with headquarters in Washington. It is largest <br> internet-based in the United States. E-commerce<br> started as an online blog but soon diversified,<br> selling mobile phones.E-store also sells certain <br> low-end products like USB cables and other accessories. E-Store has seperate retail websites<br>  for united States ,United Kingdom ,Ireland,Canada,<br> France,Germany,Italy,Spain,The Netherlands,<br>Australia,Brazil,Japan,China,India and Mexico. Amazon also offers international shipping to certain other places in the World.Many people make their daily purchases online. Today, there are online shops even of grocers. Rice, pulse, oil, and stationary goods are also bought online. The online grocery stores also sell fruits, vegetables, potato, onions, bread, butter, etc.There are online shopping websites that sell toys, paper, exercise books etc.There are eCommerce websites to buy products for babies. They sell almost everything that a kid may ever need.The most important advantage of online shopping is that we can compare the prices of various items across several eCommerce website. In this way, we are assured the best deal. </p>
        </div>
    
    <div class="container">
        <div class="col-md-4 sm-6">
            <h2>OUR HISTORY</h2>
            <br><br>
           <h4>1998-</h4><br>
           <p>The company was founded in 1998 , spurred by <br> what Velos called his efforts as an initiate to paticipate in  the Internet business boom during<br> that time.In  1998,Velos left his employement as<br> president of Ofcol & Co and moved to Seattle.<br> He began to work on a business plan for what would eventally become E-Store. 
         </p>
         <br>

        <h4>2002-</h4><br>
        <p>In January 2002, E-store has recieved a funding <br> of $12 million from Venture Partners and Indo-US <br> Venture Partners.</p><br>
        <h4>2008-</h4><br>
        <p>In July 2008, The company raised a further $45 <br> million from Bessemer Venture Partners , along<br> with existing investors Venture Partners and Indo-<br>US Venture Partners.</p><br>
        <h4>2015-</h4><br>
        <p>E-Store recieved its 3rd round of funding of $133 <br> million on Feb-2015. The 3rd round of funding <br> was led by F.com with all the current institutional <br> investors  , including Kalaari Capital, Venture. <br> Today E-store met person everyday essentials</p>
        <br>
        <br>

        </div>
        <div class="container">
        <div class="col-md-4 sm-6">
            <h2>OPPORTUNITIES</h2><br>
            <h5>Available Roles</h5><br>
            <ol>
                <li>Jr./Sr. Web Developer [Full Time Role + also <br> available as a 6 Months Internships] </li><br>
                <li>Business Apprentice [6 Months Internship]</li>
                <br>
                <li>Manager at backend operations [Full Time Role <br>+also available as a 6 Months Internship].</li>
            </ol>
           
            
        </div>
    </div>
</div>
</div>

<?php include 'includes/footer.php'; ?>

</body>
</html>